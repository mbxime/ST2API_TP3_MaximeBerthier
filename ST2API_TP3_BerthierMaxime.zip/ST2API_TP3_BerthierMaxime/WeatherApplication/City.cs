﻿using System;
namespace WeatherApplication
{
    public class City
    {
        public string _name { get; set; }

        public City(string name)
        {
            _name = name;
        }
    }
}
