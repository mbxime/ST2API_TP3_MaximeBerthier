﻿using System;
using Microsoft.AspNetCore.Mvc;

namespace WeatherApplication.Controllers
{
    public class CityController : Controller
    {
        public string name;

        public CityController()
        {
        }

        //public ActionResult Details(string _city, string _description)
        //{
            //Api Weather = new Api();
            //City myCity = new City(_city);
            //Root weather = Weather.Request(myCity);
            //return weather.main._description;
        //}
    }
}
