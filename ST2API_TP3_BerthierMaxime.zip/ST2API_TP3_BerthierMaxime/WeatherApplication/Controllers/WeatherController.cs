﻿using System;
using Microsoft.AspNetCore.Mvc;
namespace WeatherApplication.Controllers
{
    public class WeatherController : Controller
    {
        public string name;

        public WeatherController()
        {
            
        }
    }
}
