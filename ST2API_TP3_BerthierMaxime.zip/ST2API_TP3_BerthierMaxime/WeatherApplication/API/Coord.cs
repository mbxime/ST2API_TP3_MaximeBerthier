﻿using System;
namespace WeatherApplication.API
{
    public class Coord
    {
        public double lon { get; set; }
        public double lat { get; set; }
    }
}
