﻿using System;
namespace WeatherApplication.API
{
    public class Clouds
    {
        public int all { get; set; }
    }
}
